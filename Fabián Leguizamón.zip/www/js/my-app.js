// Let's register Template7 helper so we can pass json string in links
Template7.registerHelper('json_stringify', function (context) {
	return JSON.stringify(context);
});

/* Productos de la Canasta Básica
var json='';
*/

// Expose Internal DOM library
var $$ = Dom7;

// Init App
var myApp = new Framework7({
	modalTitle: 'Bolsillos Cuidados',
	// Enable Material theme
	material: true,
	// Enable templates auto precompilation
	precompileTemplates: true,
	// Enabled pages rendering using Template7
	template7Pages: true,
	customSearch: true
});


// Add main view
var mainView = myApp.addView('.view-main');

myApp.showPreloader('Cargando notas');
$$.getJSON("http://fabianleguizamon.com.ar/wp-json/wp/v2/posts", function(jsondata){
	myApp.hidePreloader();
	var old=jsondata; 
	//next - your code  
	//var old=data;
	var obj=[];
	for(var i=0;i<old.length;i++){
		var tit=old[i]["title"];
		var con=old[i]["content"];
		var exc=old[i]["excerpt"];
		var fec=new Date(old[i]["date_gmt"]);
		var fec2 = fec.getDate() + '/' +  (fec.getMonth() + 1) + '/' + fec.getFullYear();
		var img=old[i]["better_featured_image"]["media_details"]["sizes"]["oblique-entry-thumb"];
		var bdy=old[i]["acf"];
		var o=[];
		var t={};
		var z={};
		t.id=i+1;
		t.titulo=tit["rendered"];
		t.contenido=con["rendered"];
		t.bajada=exc["rendered"];
		t.enlace=img["source_url"];
		t.fecha=fec2;
		obj.push(t);	
	}
	
	

	var myList = myApp.virtualList('.list-block.media-list.virtual-list.accordion-list', {
		items: obj,
		template: 
		'<li class="accordion-item">' +
		'<a href="#" class="item-link item-content">' +
		'<div class="item-inner">' +
		'<div class="item-title-row">' +
		'<div class="item-title">{{titulo}}</div>' +
		'</div>' +
		'<div class="item-text">{{fecha}}</div>' +
		'</div>' +
		'</a>' +
		'<div class="accordion-item-content">' +
		'<div class="content-block">' +
		'<div class="row">' +
		'<div class="col-100"><img src="{{enlace}}" class="responsive"></div>' +
		'</div>' +
		'<p>{{contenido}}</p>' +
		'</div>' +
		'</div>' +
		'</li>',
		// search all items, we need to return array with indexes of matched items
		searchAll: function (query, items) {
		var foundItems = [];
		for (var i = 0; i < items.length; i++) {
		// Check if title contains query string
		if (items[i].title.indexOf(query.trim()) >= 0) foundItems.push(i);
		}
		 // Return array with indexes of matched items
		 return foundItems; 
		 }
	});
	
	console.log(JSON.stringify(obj,null,2));
	
	
	
	/* ===== Generate Content Dynamically ===== 
	var dynamicPageIndex = 0;
	function createContentPage() {		
		mainView.router.loadContent(			
			'  <!-- Page, data-page contains page name-->' +			
			'  <div id="dynamic-content" data-page="dynamic-content" class="page">' +
			'    <!-- Top Navbar-->' +
			'    <div class="navbar">' +
			'      <div class="navbar-inner">' +
			'        <div class="left"><a href="#" class="back link icon-only"><i class="icon icon-back"></i></a></div>' +
			'        <div class="center">Dynamic Page ' + (++dynamicPageIndex) + '</div>' +
			'      </div>' +
			'    </div>' +
			'    <!-- Scrollable page content-->' +
			'    <div class="page-content">' +
			'      <div class="content-block">' +
			'        <p>Here is a dynamic page created on ' + new Date() + ' !</p>' +
			'        <p>Go <a href="#" class="back">back</a> or generate <a href="#" class="ks-generate-page">one more page</a>.</p>' +
			'      </div>' +
			'    </div>' +
			'  </div>'			
		);
		return;
	}
	$$(document).on('click', '.ks-generate-page', createContentPage);*/
	
	
});
//Load new content as new page
//mainView.router.loadContent(newPageContent);




/* ===== Change statusbar bg when panel opened/closed ===== */
$$('.panel-left').on('open', function () {
	$$('.statusbar-overlay').addClass('with-panel-left');
});
$$('.panel-right').on('open', function () {
	$$('.statusbar-overlay').addClass('with-panel-right');
});
$$('.panel-left, .panel-right').on('close', function () {
	$$('.statusbar-overlay').removeClass('with-panel-left with-panel-right');
});
