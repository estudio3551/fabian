WP.ini("http://www.fabianleguizamon.com.ar","chckf4l316ga51sCAr197901", "DEBUG");
	initWP(); //MUESTRA EL MENU

	function initWP() {
	WP.categories(function(result) {
		for(i=0;i<result.length;i++) {
			$("#categorias").append('<li onclick="categoria('+result[i]['term_id']+')"> \
'+result[i]['name']+' \
</li>');
		}
		home();
	});
}
function home() {
	WP.home(function(result){
		$("#contenido").html('<ul id="listadoContenido"></ul>');
		for(i=0;i<result.length;i++) {
			console.log("Fila" + i);
			var extracto = result[i]['post_content'].slice(0,150);
			var final = extracto.replace(/<(?:.|\n)*?>/gm, '');
			$("#listadoContenido").append('<li onclick="post('+result[i]['ID']+')"> \
<h2>'+result[i]['post_title']+'</h2> \
<div class="extracto">'+final+'...</div> \
</li>');
		} 
	});
}
function categoria(id) {
	menu();
	WP.category(function(result){ 
		$("#contenido").html('<ul id="listadoContenido"></ul>');
		for(i=0;i<result.length;i++) {
			console.log("Fila" + i);
			var extracto = result[i]['post_content'].slice(0,350);
			var final = extracto.replace(/<(?:.|\n)*?>/gm, '');
			$("#listadoContenido").append('<li onclick="post('+result[i]['ID']+')"> \
<h2>'+result[i]['post_title']+'</h2> \
<div class="extracto">'+final+'...</div> \
</li>');
		} 
	}, id);
}
function post(id) {
	WP.post(function(result){
		$("#contenido").html("");
		$("#contenido").append('<h1>'+result['post_title']+'</h1>');
		$("#contenido").append(result['post_content']);
		//Mostramos comentarios debajo del POST
		WP.comment(function(result) {
			for(i=0;i<result.length;i++) {
				$("#contenido").append('<div>'+result[i]['comment_content']+'</div>');
			}
		},id);
	}, id);
}
function menu() {
	$("#app").toggleClass("openMenu");
}
document.addEventListener('deviceready', init, false);